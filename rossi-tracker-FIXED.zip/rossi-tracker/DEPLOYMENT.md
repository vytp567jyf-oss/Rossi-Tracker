# Rossi Tracker - Deployment Guide

## Quick Start (5 Minutes)

### 1. Prerequisites Checklist
- [ ] Node.js 18+ installed
- [ ] PostgreSQL database ready
- [ ] Resend account created (free at resend.com)
- [ ] Git installed

### 2. Clone and Install
\`\`\`bash
git clone <your-repo-url>
cd rossi-tracker
npm install
\`\`\`

### 3. Environment Setup
\`\`\`bash
cp .env.example .env
\`\`\`

Edit `.env` with your values:
\`\`\`env
# REQUIRED: Your PostgreSQL connection
DATABASE_URL="postgresql://username:password@host:5432/database"

# REQUIRED: Generate with: openssl rand -base64 32
NEXTAUTH_SECRET="paste-your-generated-secret-here"

# REQUIRED: Get free API key from resend.com
RESEND_API_KEY="re_your_resend_api_key"
FROM_EMAIL="noreply@yourdomain.com"

# REQUIRED: Your deployment URL (change in production)
NEXTAUTH_URL="http://localhost:3000"
APP_URL="http://localhost:3000"

# Already configured for Rossi Tracker Strava club
STRAVA_CLUB_ID="1944957"
STRAVA_CLUB_URL="https://www.strava.com/clubs/1944957"

# Enable in production
ENABLE_CRON_JOBS="true"
\`\`\`

### 4. Database Setup
\`\`\`bash
# Create database and tables
npm run prisma:migrate

# (Optional) View database
npm run prisma:studio
\`\`\`

### 5. Create Uploads Directory
\`\`\`bash
mkdir -p public/uploads/profiles
\`\`\`

### 6. Run Locally
\`\`\`bash
npm run dev
\`\`\`

Visit http://localhost:3000

---

## Production Deployment

### Option 1: Vercel (Recommended - Easiest)

#### Step 1: Prepare Repository
\`\`\`bash
git init
git add .
git commit -m "Initial commit"
git remote add origin <your-github-repo>
git push -u origin main
\`\`\`

#### Step 2: Create Vercel Project
1. Go to https://vercel.com
2. Click "Add New Project"
3. Import your GitHub repository
4. Vercel will auto-detect Next.js

#### Step 3: Configure Environment Variables
In Vercel project settings, add all variables from `.env`:
- DATABASE_URL
- NEXTAUTH_SECRET
- NEXTAUTH_URL (use your vercel URL)
- APP_URL (use your vercel URL)
- RESEND_API_KEY
- FROM_EMAIL
- STRAVA_CLUB_ID
- STRAVA_CLUB_URL
- ENABLE_CRON_JOBS

#### Step 4: Database Options

**Option A: Vercel Postgres**
\`\`\`bash
# In Vercel project, go to Storage tab
# Create Postgres database
# Copy DATABASE_URL to environment variables
\`\`\`

**Option B: External PostgreSQL (Supabase, Railway, etc.)**
\`\`\`bash
# Use your external database URL
# Add to Vercel environment variables
\`\`\`

#### Step 5: Deploy
\`\`\`bash
# Push to GitHub triggers auto-deploy
git push origin main
\`\`\`

#### Step 6: Run Database Migrations
\`\`\`bash
# In Vercel project settings, add build command:
# Build Command: npm run build && npx prisma migrate deploy
\`\`\`

#### Step 7: Set Up Cron Jobs
Vercel has built-in cron support. Create `vercel.json`:
\`\`\`json
{
  "crons": [
    {
      "path": "/api/cron/scrape-strava",
      "schedule": "0 0,12 * * *"
    },
    {
      "path": "/api/cron/send-reminders",
      "schedule": "0 7 * * 1"
    }
  ]
}
\`\`\`

Then create the cron API routes:
- `/src/app/api/cron/scrape-strava/route.ts`
- `/src/app/api/cron/send-reminders/route.ts`

---

### Option 2: Self-Hosted (VPS, AWS, etc.)

#### Requirements
- Ubuntu 22.04+ (or similar)
- Node.js 18+
- PostgreSQL
- Nginx (for reverse proxy)
- PM2 (for process management)

#### Step 1: Server Setup
\`\`\`bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Install PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Install PM2
sudo npm install -g pm2

# Install Nginx
sudo apt install -y nginx
\`\`\`

#### Step 2: PostgreSQL Setup
\`\`\`bash
# Create database and user
sudo -u postgres psql

CREATE DATABASE rossi_tracker;
CREATE USER rossi_user WITH PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE rossi_tracker TO rossi_user;
\q
\`\`\`

#### Step 3: Deploy Application
\`\`\`bash
# Clone repository
cd /var/www
git clone <your-repo-url>
cd rossi-tracker

# Install dependencies
npm install

# Set up environment
cp .env.example .env
nano .env  # Edit with your values

# Run database migrations
npx prisma migrate deploy

# Build application
npm run build

# Start with PM2
pm2 start npm --name "rossi-tracker" -- start
pm2 save
pm2 startup  # Follow instructions
\`\`\`

#### Step 4: Nginx Configuration
\`\`\`bash
sudo nano /etc/nginx/sites-available/rossi-tracker
\`\`\`

Add:
\`\`\`nginx
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
\`\`\`

Enable site:
\`\`\`bash
sudo ln -s /etc/nginx/sites-available/rossi-tracker /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
\`\`\`

#### Step 5: SSL with Let's Encrypt
\`\`\`bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
\`\`\`

#### Step 6: Set Up Cron Jobs
\`\`\`bash
crontab -e
\`\`\`

Add:
\`\`\`cron
# Scrape Strava at midnight and noon
0 0,12 * * * cd /var/www/rossi-tracker && /usr/bin/node scripts/scrape-strava.js >> /var/log/rossi-strava.log 2>&1

# Send reminders Monday 7am
0 7 * * 1 cd /var/www/rossi-tracker && /usr/bin/node scripts/send-reminders.js >> /var/log/rossi-reminders.log 2>&1
\`\`\`

---

## Post-Deployment Setup

### 1. Create First Admin User
\`\`\`bash
# Register normally through the app, then:
npm run prisma:studio
# Set isAdmin = true for your user
\`\`\`

### 2. Test Email Delivery
- Register a test account
- Check email verification works
- Wait for Monday reminder (or trigger manually)

### 3. Test Strava Integration
- Join Strava club: https://www.strava.com/clubs/1944957
- Add Strava username in profile
- Run manual scrape: `npm run scrape:strava`
- Check activities appear in dashboard

### 4. Monitor Logs
\`\`\`bash
# PM2 logs (self-hosted)
pm2 logs rossi-tracker

# Vercel logs
# Check in Vercel dashboard
\`\`\`

---

## Troubleshooting

### Database Connection Failed
\`\`\`bash
# Test connection
npx prisma db push

# Check connection string format:
# postgresql://USER:PASSWORD@HOST:PORT/DATABASE
\`\`\`

### Email Not Sending
1. Check Resend API key is correct
2. Verify domain in Resend dashboard
3. Check FROM_EMAIL matches verified domain
4. Review Resend logs for errors

### Strava Scraper Issues
1. Verify club is public
2. Check usernames match exactly
3. Test manually: `npm run scrape:strava`
4. Check network connectivity

### Cron Jobs Not Running
\`\`\`bash
# Vercel: Check function logs in dashboard
# Self-hosted: Check cron logs
tail -f /var/log/rossi-strava.log
\`\`\`

---

## Maintenance

### Update Application
\`\`\`bash
git pull origin main
npm install
npm run build
pm2 restart rossi-tracker  # Self-hosted
# Or git push for Vercel auto-deploy
\`\`\`

### Database Backup
\`\`\`bash
# Self-hosted
pg_dump -U rossi_user rossi_tracker > backup_$(date +%Y%m%d).sql

# Restore
psql -U rossi_user rossi_tracker < backup_20260128.sql
\`\`\`

### Monitor Performance
\`\`\`bash
# Self-hosted
pm2 monit

# Vercel
# Use Vercel Analytics dashboard
\`\`\`

---

## Security Checklist

- [ ] NEXTAUTH_SECRET is strong and unique
- [ ] DATABASE_URL uses strong password
- [ ] SSL/HTTPS enabled in production
- [ ] Environment variables not committed to git
- [ ] Resend API key kept secure
- [ ] Regular database backups configured
- [ ] Server firewall configured (self-hosted)
- [ ] PM2 process monitoring (self-hosted)

---

## Support

For issues or questions:
1. Check the README.md
2. Review this deployment guide
3. Check application logs
4. Open GitHub issue

---

**You're all set! 🎉**

Your Rossi Tracker platform is ready for your club to start tracking weight loss and fitness activities together!
\`\`\`
