const cron = require('node-cron');
const { scrapeStravaClub } = require('./scrape-strava');
const { sendWeeklyReminders } = require('./send-reminders');

// Enable/disable cron jobs via environment variable
const ENABLE_CRON = process.env.ENABLE_CRON_JOBS === 'true';

/**
 * Schedule Strava club scraping twice daily at 12:00 and 00:00
 */
function scheduleStravaScraper() {
  if (!ENABLE_CRON) {
    console.log('Cron jobs disabled. Set ENABLE_CRON_JOBS=true to enable.');
    return;
  }

  // Run at midnight (00:00)
  cron.schedule('0 0 * * *', async () => {
    console.log('Running scheduled Strava scrape at midnight...');
    await scrapeStravaClub();
  }, {
    timezone: 'Europe/London' // Adjust to your timezone
  });

  // Run at noon (12:00)
  cron.schedule('0 12 * * *', async () => {
    console.log('Running scheduled Strava scrape at noon...');
    await scrapeStravaClub();
  }, {
    timezone: 'Europe/London' // Adjust to your timezone
  });

  console.log('Strava scraper scheduled: 00:00 and 12:00 daily');
}

/**
 * Schedule weekly weight reminder emails every Monday at 7:00 AM
 */
function scheduleWeeklyReminders() {
  if (!ENABLE_CRON) {
    return;
  }

  // Run every Monday at 7:00 AM
  cron.schedule('0 7 * * 1', async () => {
    console.log('Sending weekly weight reminders...');
    await sendWeeklyReminders();
  }, {
    timezone: 'Europe/London' // Adjust to your timezone
  });

  console.log('Weekly reminders scheduled: Monday 07:00');
}

/**
 * Initialize all scheduled tasks
 */
function initializeScheduler() {
  scheduleStravaScraper();
  scheduleWeeklyReminders();
  console.log('All cron jobs initialized');
}

module.exports = {
  initializeScheduler,
  scheduleStravaScraper,
  scheduleWeeklyReminders,
};
