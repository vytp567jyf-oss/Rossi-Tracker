#!/usr/bin/env node

/**
 * Rossi Tracker - Initial Setup Script
 * Run with: node scripts/setup.js
 */

const readline = require('readline');
const fs = require('fs').promises;
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

const question = (query) => new Promise((resolve) => rl.question(query, resolve));

const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  green: '\x1b[32m',
  blue: '\x1b[34m',
  yellow: '\x1b[33m',
  red: '\x1b[31m',
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

function header(message) {
  console.log('\n' + '='.repeat(60));
  log(message, 'bright');
  console.log('='.repeat(60) + '\n');
}

async function checkNodeVersion() {
  const version = process.version;
  const major = parseInt(version.slice(1).split('.')[0]);
  
  if (major < 18) {
    log('❌ Node.js 18 or higher is required', 'red');
    log(`Current version: ${version}`, 'yellow');
    process.exit(1);
  }
  
  log(`✓ Node.js version: ${version}`, 'green');
}

async function generateSecret() {
  const crypto = require('crypto');
  return crypto.randomBytes(32).toString('base64');
}

async function createEnvFile() {
  header('Environment Configuration');
  
  log('Let\'s set up your environment variables...', 'blue');
  
  const databaseUrl = await question('\n📊 PostgreSQL connection string:\n(Format: postgresql://user:password@host:5432/database)\n> ');
  
  const resendKey = await question('\n📧 Resend API key:\n(Get free key at https://resend.com)\n> ');
  
  const fromEmail = await question('\n✉️  From email address:\n(e.g., noreply@yourdomain.com)\n> ');
  
  const appUrl = await question('\n🌐 App URL:\n(Use http://localhost:3000 for development)\n> ');
  
  log('\n⚙️  Generating secure NEXTAUTH_SECRET...', 'yellow');
  const secret = await generateSecret();
  
  const envContent = `# Database
DATABASE_URL="${databaseUrl}"

# NextAuth
NEXTAUTH_URL="${appUrl}"
NEXTAUTH_SECRET="${secret}"

# Resend Email API
RESEND_API_KEY="${resendKey}"
FROM_EMAIL="${fromEmail}"

# Strava Club Settings
STRAVA_CLUB_ID="1944957"
STRAVA_CLUB_URL="https://www.strava.com/clubs/1944957"

# App Settings
APP_NAME="Rossi Tracker"
APP_URL="${appUrl}"

# File Upload
MAX_FILE_SIZE=5242880
UPLOAD_DIR="./public/uploads"

# Cron Jobs
ENABLE_CRON_JOBS="true"
`;

  await fs.writeFile('.env', envContent);
  log('✓ .env file created successfully!', 'green');
}

async function setupDatabase() {
  header('Database Setup');
  
  const setup = await question('Would you like to set up the database now? (y/n): ');
  
  if (setup.toLowerCase() === 'y') {
    try {
      log('\n⚙️  Running Prisma migrations...', 'yellow');
      await execPromise('npx prisma migrate dev --name init');
      log('✓ Database setup complete!', 'green');
    } catch (error) {
      log('❌ Database setup failed. You can run it manually with: npm run prisma:migrate', 'red');
      log(`Error: ${error.message}`, 'yellow');
    }
  } else {
    log('⏭️  Skipping database setup. Run "npm run prisma:migrate" when ready.', 'yellow');
  }
}

async function createDirectories() {
  header('Creating Directories');
  
  try {
    await fs.mkdir('public/uploads/profiles', { recursive: true });
    await fs.writeFile('public/uploads/.gitkeep', '');
    log('✓ Upload directories created!', 'green');
  } catch (error) {
    log('❌ Failed to create directories', 'red');
    log(`Error: ${error.message}`, 'yellow');
  }
}

async function installDependencies() {
  header('Installing Dependencies');
  
  const install = await question('Would you like to install dependencies now? (y/n): ');
  
  if (install.toLowerCase() === 'y') {
    try {
      log('\n⚙️  Installing npm packages...', 'yellow');
      log('This may take a few minutes...', 'blue');
      await execPromise('npm install');
      log('✓ Dependencies installed!', 'green');
      return true;
    } catch (error) {
      log('❌ Installation failed. You can run it manually with: npm install', 'red');
      log(`Error: ${error.message}`, 'yellow');
      return false;
    }
  } else {
    log('⏭️  Skipping installation. Run "npm install" when ready.', 'yellow');
    return false;
  }
}

async function showNextSteps(installed) {
  header('Setup Complete! 🎉');
  
  log('Your Rossi Tracker is almost ready!', 'green');
  
  console.log('\nNext steps:');
  
  if (!installed) {
    log('\n1. Install dependencies:', 'blue');
    log('   npm install', 'bright');
  }
  
  log('\n' + (installed ? '1' : '2') + '. Review your .env file and make any necessary changes', 'blue');
  
  log('\n' + (installed ? '2' : '3') + '. If you haven\'t run database migrations yet:', 'blue');
  log('   npm run prisma:migrate', 'bright');
  
  log('\n' + (installed ? '3' : '4') + '. Start the development server:', 'blue');
  log('   npm run dev', 'bright');
  
  log('\n' + (installed ? '4' : '5') + '. Visit http://localhost:3000 in your browser', 'blue');
  
  log('\n' + (installed ? '5' : '6') + '. Create your first account and start tracking!', 'blue');
  
  console.log('\n📚 Documentation:');
  log('   - README.md - Full documentation', 'bright');
  log('   - DEPLOYMENT.md - Deployment guide', 'bright');
  
  console.log('\n💡 Tips:');
  log('   - Test Strava scraping: npm run scrape:strava', 'bright');
  log('   - View database: npm run prisma:studio', 'bright');
  log('   - Make yourself admin via Prisma Studio', 'bright');
  
  console.log('\n' + '='.repeat(60) + '\n');
}

async function main() {
  console.log('\n');
  log('╔═══════════════════════════════════════════════════════╗', 'blue');
  log('║                                                       ║', 'blue');
  log('║         🏃 ROSSI TRACKER - SETUP WIZARD 🏃            ║', 'bright');
  log('║                                                       ║', 'blue');
  log('║     Weight Loss & Fitness Tracking for Clubs         ║', 'blue');
  log('║                                                       ║', 'blue');
  log('╚═══════════════════════════════════════════════════════╝', 'blue');
  console.log('\n');
  
  await checkNodeVersion();
  
  const proceed = await question('\nReady to set up Rossi Tracker? (y/n): ');
  
  if (proceed.toLowerCase() !== 'y') {
    log('\nSetup cancelled. Run this script again when ready!', 'yellow');
    rl.close();
    return;
  }
  
  // Check if .env already exists
  try {
    await fs.access('.env');
    const overwrite = await question('\n⚠️  .env file already exists. Overwrite? (y/n): ');
    if (overwrite.toLowerCase() !== 'y') {
      log('Keeping existing .env file', 'yellow');
    } else {
      await createEnvFile();
    }
  } catch {
    await createEnvFile();
  }
  
  await createDirectories();
  const installed = await installDependencies();
  await setupDatabase();
  await showNextSteps(installed);
  
  rl.close();
}

main().catch((error) => {
  log('\n❌ Setup failed with error:', 'red');
  console.error(error);
  rl.close();
  process.exit(1);
});
