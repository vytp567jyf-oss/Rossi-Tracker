import { NextRequest, NextResponse } from 'next/server';

// This route is called by Vercel Cron
// Schedule: 0 7 * * 1 (Monday 7am)

const { sendWeeklyReminders } = require('@/../../scripts/send-reminders');

export async function GET(request: NextRequest) {
  // Verify request is from Vercel Cron
  const authHeader = request.headers.get('authorization');
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    console.log('[Vercel Cron] Sending weekly reminders...');
    const result = await sendWeeklyReminders();
    
    return NextResponse.json({
      success: true,
      message: 'Weekly reminders sent',
      result,
    });
  } catch (error: any) {
    console.error('[Vercel Cron] Reminder sending failed:', error);
    return NextResponse.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 }
    );
  }
}
