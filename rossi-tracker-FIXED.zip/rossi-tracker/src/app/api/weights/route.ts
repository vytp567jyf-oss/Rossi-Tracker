import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { calculateBMI } from '@/lib/utils';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId') || session.user.id;
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');

    const where: any = { userId };

    if (startDate || endDate) {
      where.date = {};
      if (startDate) where.date.gte = new Date(startDate);
      if (endDate) where.date.lte = new Date(endDate);
    }

    const weights = await prisma.weight.findMany({
      where,
      orderBy: { date: 'asc' },
      include: {
        user: {
          select: {
            firstName: true,
            lastName: true,
            weightUnit: true,
          },
        },
      },
    });

    return NextResponse.json(weights);
  } catch (error) {
    console.error('Error fetching weights:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { weight, date } = body;

    if (!weight || !date) {
      return NextResponse.json(
        { error: 'Weight and date are required' },
        { status: 400 }
      );
    }

    // Get user's height for BMI calculation
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { height: true },
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Calculate BMI
    const bmi = calculateBMI(parseFloat(weight), user.height);

    // Check if weight entry for this date already exists
    const existingWeight = await prisma.weight.findFirst({
      where: {
        userId: session.user.id,
        date: new Date(date),
      },
    });

    let weightEntry;

    if (existingWeight) {
      // Update existing entry
      weightEntry = await prisma.weight.update({
        where: { id: existingWeight.id },
        data: {
          weight: parseFloat(weight),
          bmi,
        },
      });
    } else {
      // Create new entry
      weightEntry = await prisma.weight.create({
        data: {
          userId: session.user.id,
          weight: parseFloat(weight),
          date: new Date(date),
          bmi,
        },
      });
    }

    // Update user's lastWeightEntry
    await prisma.user.update({
      where: { id: session.user.id },
      data: { lastWeightEntry: new Date(date) },
    });

    return NextResponse.json(weightEntry, { status: 201 });
  } catch (error) {
    console.error('Error creating weight entry:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const weightId = searchParams.get('id');

    if (!weightId) {
      return NextResponse.json({ error: 'Weight ID is required' }, { status: 400 });
    }

    // Verify ownership
    const weight = await prisma.weight.findUnique({
      where: { id: weightId },
    });

    if (!weight || weight.userId !== session.user.id) {
      return NextResponse.json({ error: 'Weight entry not found' }, { status: 404 });
    }

    await prisma.weight.delete({
      where: { id: weightId },
    });

    return NextResponse.json({ message: 'Weight entry deleted' });
  } catch (error) {
    console.error('Error deleting weight entry:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
