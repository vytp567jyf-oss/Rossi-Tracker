/**
 * Utility functions for weight, height, and BMI calculations
 */

// Weight conversions
export function kgToLbs(kg: number): number {
  return kg * 2.20462;
}

export function lbsToKg(lbs: number): number {
  return lbs / 2.20462;
}

// Height conversions
export function cmToInches(cm: number): number {
  return cm / 2.54;
}

export function inchesToCm(inches: number): number {
  return inches * 2.54;
}

export function cmToFeetAndInches(cm: number): { feet: number; inches: number } {
  const totalInches = cmToInches(cm);
  const feet = Math.floor(totalInches / 12);
  const inches = Math.round(totalInches % 12);
  return { feet, inches };
}

export function feetAndInchesToCm(feet: number, inches: number): number {
  return inchesToCm(feet * 12 + inches);
}

// BMI calculation
export function calculateBMI(weightKg: number, heightCm: number): number {
  const heightM = heightCm / 100;
  return Number((weightKg / (heightM * heightM)).toFixed(1));
}

// BMI category
export function getBMICategory(bmi: number): string {
  if (bmi < 18.5) return 'Underweight';
  if (bmi < 25) return 'Normal weight';
  if (bmi < 30) return 'Overweight';
  return 'Obese';
}

// Format weight display
export function formatWeight(weightKg: number, unit: 'metric' | 'imperial'): string {
  if (unit === 'imperial') {
    return `${kgToLbs(weightKg).toFixed(1)} lbs`;
  }
  return `${weightKg.toFixed(1)} kg`;
}

// Format height display
export function formatHeight(heightCm: number, unit: 'metric' | 'imperial'): string {
  if (unit === 'imperial') {
    const { feet, inches } = cmToFeetAndInches(heightCm);
    return `${feet}'${inches}"`;
  }
  return `${heightCm.toFixed(0)} cm`;
}

// Format distance
export function formatDistance(meters: number, imperial: boolean = false): string {
  if (imperial) {
    const miles = meters / 1609.34;
    return `${miles.toFixed(2)} mi`;
  }
  const km = meters / 1000;
  return `${km.toFixed(2)} km`;
}

// Format elevation
export function formatElevation(meters: number, imperial: boolean = false): string {
  if (imperial) {
    const feet = meters * 3.28084;
    return `${feet.toFixed(0)} ft`;
  }
  return `${meters.toFixed(0)} m`;
}

// Calculate weight loss
export function calculateWeightLoss(startWeight: number, currentWeight: number): number {
  return Number((startWeight - currentWeight).toFixed(1));
}

// Calculate weight loss percentage
export function calculateWeightLossPercentage(startWeight: number, currentWeight: number): number {
  return Number((((startWeight - currentWeight) / startWeight) * 100).toFixed(1));
}

// Generate random verification code
export function generateVerificationCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Check if user is inactive (no weight entry for 3+ months)
export function isUserInactive(lastWeightEntry: Date | null): boolean {
  if (!lastWeightEntry) return true;
  const threeMonthsAgo = new Date();
  threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);
  return lastWeightEntry < threeMonthsAgo;
}

// Check if user should be hidden (no weight entry for 6+ months)
export function shouldHideUser(lastWeightEntry: Date | null): boolean {
  if (!lastWeightEntry) return true;
  const sixMonthsAgo = new Date();
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
  return lastWeightEntry < sixMonthsAgo;
}
