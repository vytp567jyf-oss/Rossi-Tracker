# 🚀 ROSSI TRACKER - STEP-BY-STEP INSTALLATION GUIDE

## WHERE TO RUN THE COMMANDS

All commands are run on **your computer** (Mac, Windows, or Linux) in the **Terminal** or **Command Prompt**.

---

## 📥 STEP 1: DOWNLOAD & EXTRACT

### Download the File:
1. Click the download link for `rossi-tracker.tar.gz` 
2. Save it to your computer (e.g., Downloads folder)

### Extract the Files:

**On Mac/Linux:**
```bash
# Open Terminal (Applications → Utilities → Terminal)
cd ~/Downloads
tar -xzf rossi-tracker.tar.gz
cd rossi-tracker
```

**On Windows:**
- Right-click `rossi-tracker.tar.gz`
- Select "Extract All..."
- Or use 7-Zip or WinRAR to extract
- Open Command Prompt or PowerShell
- Navigate to the extracted folder:
```bash
cd Downloads\rossi-tracker
```

---

## 🔧 STEP 2: INSTALL NODE.JS (If Not Already Installed)

### Check if you have Node.js:
```bash
node --version
```

If you see a version number like `v18.x.x` or higher, you're good! Skip to Step 3.

### If not installed:
1. Go to: https://nodejs.org
2. Download the **LTS version** (recommended)
3. Run the installer
4. Restart your Terminal/Command Prompt
5. Verify: `node --version`

---

## 🛠️ STEP 3: RUN THE SETUP WIZARD

**IMPORTANT**: Make sure you're in the `rossi-tracker` folder!

```bash
# You should be here: /path/to/rossi-tracker/
# Verify by running:
pwd          # On Mac/Linux
cd           # On Windows

# You should see the rossi-tracker folder in the path
```

### Run the Interactive Setup:
```bash
node scripts/setup.js
```

**What this does:**
- Asks you for database connection details
- Asks you for Resend email API key
- Generates secure secrets automatically
- Creates your `.env` file
- Installs dependencies
- Sets up the database
- Creates necessary folders

### You'll be asked for:

1. **PostgreSQL connection string**
   ```
   Example: postgresql://username:password@localhost:5432/rossi_tracker
   ```
   - Don't have PostgreSQL? See "Database Options" below

2. **Resend API key**
   ```
   Get it from: https://resend.com (free account)
   Example: re_123abc456def
   ```

3. **From email address**
   ```
   Example: noreply@yourdomain.com
   ```

4. **App URL**
   ```
   For local development: http://localhost:3000
   For production: https://yourdomain.com
   ```

---

## 💾 DATABASE OPTIONS

### Option 1: Local PostgreSQL

**Mac:**
```bash
brew install postgresql@15
brew services start postgresql@15
createdb rossi_tracker
```

**Windows:**
- Download from: https://www.postgresql.org/download/windows/
- Run installer
- Use pgAdmin to create database "rossi_tracker"

**Linux (Ubuntu):**
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
sudo -u postgres createdb rossi_tracker
```

### Option 2: Cloud Database (Easier!)

**Vercel Postgres** (Recommended for beginners):
1. Go to: https://vercel.com
2. Sign up (free)
3. Create new project
4. Go to Storage tab
5. Create Postgres database
6. Copy the connection string

**Supabase** (Free tier):
1. Go to: https://supabase.com
2. Create project
3. Get connection string from Settings → Database

**Railway** (Free tier):
1. Go to: https://railway.app
2. Create project
3. Add PostgreSQL
4. Copy connection string

---

## 📧 EMAIL SETUP (RESEND)

1. Go to: https://resend.com
2. Sign up (completely free - no credit card)
3. Click "API Keys"
4. Create new API key
5. Copy it (starts with `re_`)
6. Use in setup wizard

**Free tier includes:**
- 3,000 emails per month
- 100 emails per day
- Perfect for a club!

---

## ▶️ STEP 4: START THE APPLICATION

After the setup wizard completes:

```bash
npm run dev
```

**You should see:**
```
✓ Ready on http://localhost:3000
```

---

## 🌐 STEP 5: OPEN IN BROWSER

1. Open your web browser
2. Go to: **http://localhost:3000**
3. You should see the Rossi Tracker login page!

---

## 👤 STEP 6: CREATE YOUR FIRST ACCOUNT

1. Click "Sign up"
2. Fill in your details
3. Click "Create Account"
4. Check your email for verification code
5. Enter the code
6. Login!

---

## 🔑 STEP 7: MAKE YOURSELF ADMIN

**Option 1: Using Prisma Studio (Easiest)**
```bash
# Open a NEW terminal window (keep the app running in the other)
npm run prisma:studio
```

This opens a database viewer in your browser:
1. Click "User" table
2. Find your user
3. Change `isAdmin` from `false` to `true`
4. Click "Save"

**Option 2: Using Database Tool**
If you have pgAdmin or another database tool:
```sql
UPDATE "User" SET "isAdmin" = true WHERE email = 'your@email.com';
```

---

## 🏃 STEP 8: ADD YOUR FIRST WEIGHT

1. In Rossi Tracker, click the **"+ Add Weight"** button
2. Enter your weight
3. Select today's date
4. Click "Save"

You'll see it appear on the dashboard!

---

## 🚴 STEP 9: CONNECT STRAVA (OPTIONAL)

1. Join the Strava club: https://www.strava.com/clubs/1944957
2. In Rossi Tracker, click your profile picture
3. Click "My Profile"
4. Enter your **exact** Strava username
5. Click "Save"

Activities will sync automatically at:
- Midnight (00:00)
- Noon (12:00)

Or trigger manually:
```bash
npm run scrape:strava
```

---

## 📊 STEP 10: INVITE YOUR CLUB

Share this URL with club members:
```
http://localhost:3000/register
```

Once you deploy to production, you'll share your real domain!

---

## ⚙️ COMMON COMMANDS

All commands run from the `rossi-tracker` folder:

```bash
# Start development server
npm run dev

# View database
npm run prisma:studio

# Manually scrape Strava
npm run scrape:strava

# Run database migrations
npm run prisma:migrate

# Build for production
npm run build

# Start production server
npm start
```

---

## 🆘 TROUBLESHOOTING

### "Command not found: npm"
- Node.js isn't installed
- Install from: https://nodejs.org

### "Cannot connect to database"
- Check PostgreSQL is running
- Verify connection string in `.env`
- Test: `npx prisma db push`

### "Port 3000 already in use"
- Another app is using port 3000
- Stop it or use different port:
  ```bash
  PORT=3001 npm run dev
  ```

### "Email not sending"
- Check Resend API key in `.env`
- Verify email domain in Resend dashboard
- Check Resend logs

### Setup wizard not working
- Manual setup instead:
  ```bash
  cp .env.example .env
  nano .env  # or use any text editor
  # Fill in your values
  npm install
  npx prisma migrate dev
  npm run dev
  ```

---

## 📁 FILE STRUCTURE

```
rossi-tracker/                    ← YOU ARE HERE
├── scripts/
│   └── setup.js                  ← The setup wizard
├── src/                          ← Application code
├── prisma/                       ← Database
├── package.json                  ← Dependencies
├── .env                          ← Your config (created by wizard)
└── README.md                     ← Documentation
```

---

## ✅ CHECKLIST

Before asking for help, verify:

- [ ] Node.js 18+ installed (`node --version`)
- [ ] In the `rossi-tracker` folder (`pwd` or `cd`)
- [ ] PostgreSQL database created
- [ ] Resend account created
- [ ] `.env` file exists
- [ ] Ran `npm install`
- [ ] Ran database migrations

---

## 🚀 READY TO DEPLOY?

Once everything works locally, see:
- **DEPLOYMENT.md** for production deployment
- Vercel deployment (easiest)
- Self-hosting options

---

## 💡 QUICK TIPS

1. **Keep the terminal open** while the app runs
2. **Use a second terminal** for other commands
3. **Ctrl+C** to stop the server
4. **Save changes** - Next.js auto-reloads
5. **Check logs** if something breaks

---

**Need more help?** 
- Check README.md
- Check DEPLOYMENT.md
- Review error messages carefully
- All commands assume you're in the `rossi-tracker` folder!

---

Good luck! 🎉
