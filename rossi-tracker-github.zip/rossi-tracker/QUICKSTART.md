# Quick Start Guide - Rossi Tracker

## 🚀 Get Running in 5 Minutes

### Step 1: Setup (Automated)
\`\`\`bash
node scripts/setup.js
\`\`\`

The setup wizard will walk you through:
- ✓ Environment configuration
- ✓ Database setup
- ✓ Directory creation
- ✓ Dependency installation

### Step 2: Start Development
\`\`\`bash
npm run dev
\`\`\`

Visit: http://localhost:3000

### Step 3: Create Your Account
1. Click "Sign up"
2. Fill in your details
3. Check your email for verification code
4. Verify and login

### Step 4: Set Up Your Profile
1. Enter your Strava username (if using Strava)
2. Add your initial weights:
   - 5th Jan 2026
   - 12th Jan 2026
   - 19th Jan 2026
   - 26th Jan 2026

### Step 5: Invite Your Club
Share the registration link with club members!

---

## 📝 What You Need Before Starting

### Required:
- [ ] Node.js 18+
- [ ] PostgreSQL database
- [ ] Resend account (free)

### Optional but Recommended:
- [ ] Strava account
- [ ] Custom domain
- [ ] SSL certificate (for production)

---

## 🎯 Key Features to Try

### 1. Weight Tracking
- Add weekly weight entries
- View your progress chart
- See BMI calculations

### 2. Strava Integration
- Join the club: https://www.strava.com/clubs/1944957
- Add your Strava username in profile
- Activities sync automatically twice daily

### 3. Leaderboards
- Biggest weight loss
- Most activities
- Top cyclists/runners/swimmers
- Highest elevations

### 4. Admin Features
- Make yourself admin in Prisma Studio
- Drag charts to reorganize dashboard
- View all user stats

---

## 🔧 Common Tasks

### Make Yourself Admin
\`\`\`bash
npm run prisma:studio
# Set isAdmin = true for your user
\`\`\`

### Manually Scrape Strava
\`\`\`bash
npm run scrape:strava
\`\`\`

### View Database
\`\`\`bash
npm run prisma:studio
\`\`\`

### Reset Database
\`\`\`bash
npx prisma migrate reset
\`\`\`

---

## 📧 Email Setup (Resend)

1. Sign up: https://resend.com (free 3,000 emails/month)
2. Get API key from dashboard
3. Add to .env:
   \`\`\`
   RESEND_API_KEY="re_..."
   FROM_EMAIL="noreply@yourdomain.com"
   \`\`\`

### Test Email
Register a new account and check verification email!

---

## 🏃 Strava Setup

### For Users:
1. Join club: https://www.strava.com/clubs/1944957
2. Note your EXACT Strava username
3. Add username in Rossi profile
4. Wait for next sync (12:00 or 00:00)

### For Admins:
Scraper runs automatically at:
- 00:00 (midnight)
- 12:00 (noon)
- Or manually: `npm run scrape:strava`

---

## 🐛 Troubleshooting

### "Database connection failed"
- Check DATABASE_URL in .env
- Ensure PostgreSQL is running
- Test: `npx prisma db push`

### "Email not sending"
- Verify RESEND_API_KEY
- Check domain verification in Resend
- Review Resend dashboard logs

### "Strava activities not showing"
- Verify username matches exactly
- Check club membership
- Run manual scrape
- Check scraper logs

---

## 📚 Full Documentation

- **README.md** - Complete documentation
- **DEPLOYMENT.md** - Production deployment guide
- **CONTRIBUTING.md** - Contribution guidelines

---

## 🆘 Getting Help

1. Check README.md
2. Review DEPLOYMENT.md
3. Check application logs
4. Open GitHub issue

---

## ✨ What's Next?

After basic setup:

1. **Customize Branding**
   - Add your logo
   - Update colors in `tailwind.config.js`
   - Modify email templates

2. **Deploy to Production**
   - See DEPLOYMENT.md
   - Set up SSL
   - Configure custom domain

3. **Invite Members**
   - Share registration link
   - Set up onboarding guide
   - Create club rules

4. **Monitor & Maintain**
   - Check weekly activity
   - Review leaderboards
   - Backup database regularly

---

**Ready to transform your club's fitness journey? Let's go! 🚀**
