# Rossi Tracker

A comprehensive weight loss and fitness tracking platform for clubs with Strava integration.

## Features

- 📊 Weight tracking with BMI calculation
- 🏃 Strava club activity integration (automatic scraping)
- 📈 Interactive charts and leaderboards
- 👥 Club-wide dashboard with member comparisons
- 📧 Automated weekly email reminders
- 🎨 Beautiful, modern UI with Apple-inspired design
- 📱 Fully responsive (mobile & desktop)
- 🔐 Secure authentication with email verification
- ⚙️ Admin controls for dashboard customization

## Tech Stack

- **Frontend**: Next.js 14, React, TypeScript, Tailwind CSS
- **Backend**: Next.js API Routes, NextAuth.js
- **Database**: PostgreSQL with Prisma ORM
- **Email**: Resend (free tier: 3,000 emails/month)
- **Charts**: Recharts
- **Animations**: Framer Motion
- **Web Scraping**: Cheerio + Axios

## Prerequisites

- Node.js 18+ 
- PostgreSQL database
- Resend API key (free at https://resend.com)

## Installation

### 1. Clone the repository

\`\`\`bash
git clone <your-repo-url>
cd rossi-tracker
\`\`\`

### 2. Install dependencies

\`\`\`bash
npm install
\`\`\`

### 3. Set up environment variables

Copy `.env.example` to `.env`:

\`\`\`bash
cp .env.example .env
\`\`\`

Edit `.env` and configure:

\`\`\`env
# Database - Replace with your PostgreSQL connection string
DATABASE_URL="postgresql://user:password@localhost:5432/rossi_tracker"

# NextAuth - Generate a secret: openssl rand -base64 32
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="your-generated-secret-here"

# Resend Email API - Get free API key at https://resend.com
RESEND_API_KEY="re_your_api_key"
FROM_EMAIL="noreply@yourdomain.com"

# Strava Club (already configured)
STRAVA_CLUB_ID="1944957"
STRAVA_CLUB_URL="https://www.strava.com/clubs/1944957"

# Enable cron jobs (set to true in production)
ENABLE_CRON_JOBS="true"
\`\`\`

### 4. Set up the database

\`\`\`bash
# Run Prisma migrations
npm run prisma:migrate

# (Optional) Open Prisma Studio to view your database
npm run prisma:studio
\`\`\`

### 5. Create uploads directory

\`\`\`bash
mkdir -p public/uploads/profiles
touch public/uploads/.gitkeep
\`\`\`

### 6. Run the development server

\`\`\`bash
npm run dev
\`\`\`

Visit [http://localhost:3000](http://localhost:3000)

## Strava Integration Setup

### Club Setup
1. Users join the Strava Club: https://www.strava.com/clubs/1944957
2. In their Rossi profile, they enter their Strava username (exactly as it appears on Strava)
3. The scraper automatically matches activities to profiles twice daily (12:00 & 00:00)

### Manual Scraping
To manually scrape Strava data:

\`\`\`bash
npm run scrape:strava
\`\`\`

### Automated Scraping
The scraper runs automatically when \`ENABLE_CRON_JOBS="true"\`:
- **12:00 daily** - Noon scrape
- **00:00 daily** - Midnight scrape
- **Monday 07:00** - Weekly weight reminders

## Initial Setup for Users

### First Time Users:
1. Register at `/register`
2. Verify email with code
3. Login at `/login`
4. Complete profile with:
   - Height
   - Strava username (optional but recommended)
5. Enter initial weights for:
   - 5th Jan 2026
   - 12th Jan 2026
   - 19th Jan 2026
   - 26th Jan 2026

### Weekly Routine:
- Users receive email reminder every Monday at 7:00 AM
- Click link to login and enter weekly weight
- Dashboard automatically updates with new data

## Dashboard Features

### Weight Loss Leaderboard
- Biggest loser since Jan 1st, 2026
- Weight lost (kg/lbs)
- Percentage lost
- Current BMI

### Activity Leaderboards
- Total activities
- Most cycling sessions
- Most runs
- Most swims
- Most walks/hikes
- Most gym sessions
- Highest elevation on foot
- Highest elevation on bike
- Most cycling distance
- Most walking distance

### Charts
- Weight progression over time (multi-user comparison)
- Date range filters (custom, week, month, quarter, year)
- Color-coded by user with legend
- Interactive tooltips
- Mobile-friendly with pinch-to-zoom

## Admin Features

Admin users can:
- Drag and reposition dashboard widgets
- Customize chart layouts
- View all user statistics
- Manage user accounts

To make a user an admin:

\`\`\`bash
# Using Prisma Studio
npm run prisma:studio
# Then set isAdmin = true for the user

# Or using SQL
UPDATE "User" SET "isAdmin" = true WHERE email = 'admin@example.com';
\`\`\`

## Deployment

### Vercel (Recommended)

1. Push code to GitHub
2. Import project in Vercel
3. Add environment variables
4. Set up PostgreSQL database (Vercel Postgres or external)
5. Deploy!

### Self-Hosted

\`\`\`bash
# Build the app
npm run build

# Start production server
npm start
\`\`\`

## Email Configuration (Resend)

1. Sign up at https://resend.com (free tier: 3,000 emails/month)
2. Verify your domain or use Resend's test domain
3. Get API key from dashboard
4. Add to `.env`:

\`\`\`env
RESEND_API_KEY="re_your_key_here"
FROM_EMAIL="noreply@yourdomain.com"
\`\`\`

## Inactive User Handling

- **3 months** without weight entry → Profile grayed out
- **6 months** without weight entry → Profile hidden from leaderboards
- Users can reactivate by entering a new weight

## Project Structure

\`\`\`
rossi-tracker/
├── prisma/
│   └── schema.prisma          # Database schema
├── public/
│   └── uploads/               # User profile images
├── scripts/
│   ├── scrape-strava.js      # Strava club scraper
│   ├── send-reminders.js     # Email service
│   └── scheduler.js           # Cron jobs
├── src/
│   ├── app/
│   │   ├── api/              # API routes
│   │   ├── dashboard/        # Main dashboard
│   │   ├── login/            # Login page
│   │   ├── register/         # Registration
│   │   └── verify/           # Email verification
│   ├── components/           # React components
│   └── lib/
│       ├── auth.ts           # Authentication config
│       ├── prisma.ts         # Database client
│       └── utils.ts          # Utility functions
└── README.md
\`\`\`

## API Endpoints

- `POST /api/auth/register` - User registration
- `POST /api/auth/verify` - Email verification
- `GET/POST /api/weights` - Weight entries
- `GET /api/leaderboard` - Leaderboard data
- `GET/PUT /api/user/profile` - User profile

## Future Enhancements (White Label Ready)

The platform is designed for white-labeling with planned integrations:
- ✅ Strava (via scraping)
- 🔄 Garmin Connect
- 🔄 Apple Health
- 🔄 Withings
- 🔄 MyFitnessPal
- 🔄 Zwift
- 🔄 TrainingPeaks
- 🔄 Wattbike
- 🔄 ERGdata

## Troubleshooting

### Database Connection Issues
\`\`\`bash
# Test your database connection
npx prisma db push
\`\`\`

### Strava Scraper Not Working
- Check Strava club is public
- Verify usernames match exactly
- Check cron jobs are enabled

### Email Not Sending
- Verify Resend API key
- Check domain verification
- Review Resend dashboard logs

## Support

For issues or questions, please open an issue on GitHub.

## License

MIT License - feel free to use for your club!

---

Built with ❤️ for fitness enthusiasts
\`\`\`
