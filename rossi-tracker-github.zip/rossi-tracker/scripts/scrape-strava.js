const axios = require('axios');
const cheerio = require('cheerio');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

const STRAVA_CLUB_ID = process.env.STRAVA_CLUB_ID || '1944957';
const STRAVA_CLUB_URL = `https://www.strava.com/clubs/${STRAVA_CLUB_ID}`;

/**
 * Scrape Strava club leaderboard and recent activities
 * This fetches publicly available data from the club page
 */
async function scrapeStravaClub() {
  try {
    console.log(`[${new Date().toISOString()}] Starting Strava club scrape...`);
    
    // Fetch the club page HTML
    const response = await axios.get(STRAVA_CLUB_URL, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
    });

    const $ = cheerio.load(response.data);
    const activities = [];

    // Scrape recent club activities
    // Note: Strava's HTML structure may change, so this might need updating
    $('.feed-entry').each((index, element) => {
      const $entry = $(element);
      
      const athleteName = $entry.find('.entry-athlete').text().trim();
      const activityType = $entry.find('.entry-type').text().trim();
      const activityTitle = $entry.find('.entry-title').text().trim();
      const stats = $entry.find('.entry-stats').text().trim();
      const timestamp = $entry.find('.timestamp').attr('datetime');

      // Parse distance and elevation from stats
      let distance = null;
      let elevation = null;
      
      const distanceMatch = stats.match(/(\d+\.?\d*)\s*(km|mi)/i);
      if (distanceMatch) {
        distance = parseFloat(distanceMatch[1]);
        // Convert to meters
        distance = distanceMatch[2].toLowerCase() === 'mi' ? distance * 1609.34 : distance * 1000;
      }

      const elevationMatch = stats.match(/(\d+\.?\d*)\s*m/i);
      if (elevationMatch) {
        elevation = parseFloat(elevationMatch[1]);
      }

      if (athleteName && activityType) {
        activities.push({
          athleteName,
          activityType,
          activityTitle,
          distance,
          elevation,
          timestamp: timestamp ? new Date(timestamp) : new Date(),
        });
      }
    });

    console.log(`Scraped ${activities.length} activities from Strava club`);

    // Match athletes to Rossi users and save activities
    let savedCount = 0;
    let skippedCount = 0;

    for (const activity of activities) {
      // Find user by Strava username
      const user = await prisma.user.findFirst({
        where: {
          stravaUsername: {
            equals: activity.athleteName,
            mode: 'insensitive',
          },
        },
      });

      if (user) {
        // Check if this activity already exists (avoid duplicates)
        const existingActivity = await prisma.stravaActivity.findFirst({
          where: {
            userId: user.id,
            activityDate: activity.timestamp,
            activityType: activity.activityType,
          },
        });

        if (!existingActivity) {
          await prisma.stravaActivity.create({
            data: {
              userId: user.id,
              stravaUsername: activity.athleteName,
              activityType: activity.activityType,
              activityName: activity.activityTitle,
              distance: activity.distance,
              elevationGain: activity.elevation,
              activityDate: activity.timestamp,
            },
          });
          savedCount++;
        } else {
          skippedCount++;
        }
      }
    }

    console.log(`Saved ${savedCount} new activities, skipped ${skippedCount} duplicates`);
    console.log(`[${new Date().toISOString()}] Strava club scrape completed successfully`);

    return {
      success: true,
      scrapedActivities: activities.length,
      savedActivities: savedCount,
      skippedActivities: skippedCount,
    };

  } catch (error) {
    console.error('Error scraping Strava club:', error.message);
    return {
      success: false,
      error: error.message,
    };
  } finally {
    await prisma.$disconnect();
  }
}

/**
 * Aggregate activity statistics for leaderboards
 */
async function aggregateActivityStats() {
  try {
    console.log('Aggregating activity statistics...');

    const users = await prisma.user.findMany({
      where: { isActive: true },
      include: {
        stravaActivities: {
          where: {
            activityDate: {
              gte: new Date('2026-01-01'),
            },
          },
        },
      },
    });

    const stats = users.map(user => {
      const activities = user.stravaActivities;

      const cyclingActivities = activities.filter(a => 
        a.activityType.toLowerCase().includes('ride') || 
        a.activityType.toLowerCase().includes('cycling')
      );
      
      const runActivities = activities.filter(a => 
        a.activityType.toLowerCase().includes('run')
      );
      
      const swimActivities = activities.filter(a => 
        a.activityType.toLowerCase().includes('swim')
      );
      
      const walkActivities = activities.filter(a => 
        a.activityType.toLowerCase().includes('walk') ||
        a.activityType.toLowerCase().includes('hike')
      );
      
      const gymActivities = activities.filter(a => 
        a.activityType.toLowerCase().includes('weight') ||
        a.activityType.toLowerCase().includes('training') ||
        a.activityType.toLowerCase().includes('workout')
      );

      return {
        userId: user.id,
        totalActivities: activities.length,
        cyclingCount: cyclingActivities.length,
        runCount: runActivities.length,
        swimCount: swimActivities.length,
        walkCount: walkActivities.length,
        gymCount: gymActivities.length,
        totalCyclingDistance: cyclingActivities.reduce((sum, a) => sum + (a.distance || 0), 0),
        totalRunDistance: runActivities.reduce((sum, a) => sum + (a.distance || 0), 0),
        totalWalkDistance: walkActivities.reduce((sum, a) => sum + (a.distance || 0), 0),
        elevationOnFoot: [...runActivities, ...walkActivities].reduce((sum, a) => sum + (a.elevationGain || 0), 0),
        elevationOnBike: cyclingActivities.reduce((sum, a) => sum + (a.elevationGain || 0), 0),
      };
    });

    console.log('Activity statistics aggregated successfully');
    return stats;

  } catch (error) {
    console.error('Error aggregating statistics:', error.message);
    throw error;
  }
}

// Run scraper if called directly
if (require.main === module) {
  scrapeStravaClub()
    .then(result => {
      console.log('Scrape result:', result);
      process.exit(0);
    })
    .catch(error => {
      console.error('Fatal error:', error);
      process.exit(1);
    });
}

module.exports = {
  scrapeStravaClub,
  aggregateActivityStats,
};
