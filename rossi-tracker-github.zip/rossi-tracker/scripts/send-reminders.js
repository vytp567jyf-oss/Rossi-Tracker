const { Resend } = require('resend');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();
const resend = new Resend(process.env.RESEND_API_KEY);

/**
 * Send weekly weight entry reminders to all active users
 */
async function sendWeeklyReminders() {
  try {
    console.log(`[${new Date().toISOString()}] Sending weekly weight reminders...`);

    const users = await prisma.user.findMany({
      where: {
        isActive: true,
        emailVerified: true,
      },
    });

    const appUrl = process.env.APP_URL || 'http://localhost:3000';
    let sentCount = 0;
    let failedCount = 0;

    for (const user of users) {
      try {
        const emailHtml = generateReminderEmail(user, appUrl);

        const { data, error } = await resend.emails.send({
          from: process.env.FROM_EMAIL || 'noreply@rossitracker.com',
          to: user.email,
          subject: '📊 Rossi Tracker: Time to log your weight!',
          html: emailHtml,
        });

        if (error) {
          console.error(`Failed to send email to ${user.email}:`, error);
          failedCount++;
        } else {
          // Log the reminder
          await prisma.weeklyReminder.create({
            data: {
              userId: user.id,
              email: user.email,
              sentAt: new Date(),
            },
          });
          sentCount++;
        }
      } catch (emailError) {
        console.error(`Error sending to ${user.email}:`, emailError);
        failedCount++;
      }
    }

    console.log(`Weekly reminders sent: ${sentCount} successful, ${failedCount} failed`);

    return {
      success: true,
      sent: sentCount,
      failed: failedCount,
    };

  } catch (error) {
    console.error('Error in sendWeeklyReminders:', error);
    return {
      success: false,
      error: error.message,
    };
  } finally {
    await prisma.$disconnect();
  }
}

/**
 * Generate HTML email template for weight reminder
 */
function generateReminderEmail(user, appUrl) {
  const loginUrl = `${appUrl}/login`;
  
  return `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Weekly Weight Reminder</title>
      </head>
      <body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #0A0A0A;">
        <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #0A0A0A; padding: 40px 20px;">
          <tr>
            <td align="center">
              <table width="600" cellpadding="0" cellspacing="0" style="background-color: #FFFFFF; border-radius: 16px; overflow: hidden;">
                <!-- Header -->
                <tr>
                  <td style="background: linear-gradient(135deg, #0066FF 0%, #7C3AED 100%); padding: 40px 40px 30px; text-align: center;">
                    <h1 style="margin: 0; color: #FFFFFF; font-size: 32px; font-weight: 700;">Rossi Tracker</h1>
                    <p style="margin: 10px 0 0; color: rgba(255,255,255,0.9); font-size: 16px;">Your Weekly Check-In</p>
                  </td>
                </tr>
                
                <!-- Content -->
                <tr>
                  <td style="padding: 40px;">
                    <h2 style="margin: 0 0 20px; color: #0A0A0A; font-size: 24px; font-weight: 600;">
                      Hi ${user.firstName}! 👋
                    </h2>
                    
                    <p style="margin: 0 0 20px; color: #666666; font-size: 16px; line-height: 1.6;">
                      It's Monday morning – time to log your weekly weight on Rossi Tracker!
                    </p>
                    
                    <p style="margin: 0 0 30px; color: #666666; font-size: 16px; line-height: 1.6;">
                      Keep track of your progress and see how you're doing compared to the rest of the club.
                    </p>
                    
                    <!-- CTA Button -->
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td align="center" style="padding: 20px 0;">
                          <a href="${loginUrl}" style="display: inline-block; background: linear-gradient(135deg, #0066FF 0%, #7C3AED 100%); color: #FFFFFF; text-decoration: none; padding: 16px 40px; border-radius: 12px; font-weight: 600; font-size: 16px;">
                            Log Your Weight Now
                          </a>
                        </td>
                      </tr>
                    </table>
                    
                    <p style="margin: 30px 0 0; color: #999999; font-size: 14px; line-height: 1.6;">
                      Remember: Consistency is key! Even small progress adds up over time.
                    </p>
                  </td>
                </tr>
                
                <!-- Footer -->
                <tr>
                  <td style="background-color: #F7F7F7; padding: 30px 40px; text-align: center;">
                    <p style="margin: 0 0 10px; color: #999999; font-size: 12px;">
                      You're receiving this because you're a member of Rossi Tracker
                    </p>
                    <p style="margin: 0; color: #999999; font-size: 12px;">
                      <a href="${appUrl}/settings" style="color: #0066FF; text-decoration: none;">Manage preferences</a>
                    </p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </body>
    </html>
  `;
}

/**
 * Send verification email to new users
 */
async function sendVerificationEmail(email, code, firstName) {
  try {
    const appUrl = process.env.APP_URL || 'http://localhost:3000';
    const verifyUrl = `${appUrl}/verify?email=${encodeURIComponent(email)}&code=${code}`;

    const emailHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>Verify Your Email</title>
        </head>
        <body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #0A0A0A;">
          <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #0A0A0A; padding: 40px 20px;">
            <tr>
              <td align="center">
                <table width="600" cellpadding="0" cellspacing="0" style="background-color: #FFFFFF; border-radius: 16px; overflow: hidden;">
                  <tr>
                    <td style="background: linear-gradient(135deg, #0066FF 0%, #7C3AED 100%); padding: 40px; text-align: center;">
                      <h1 style="margin: 0; color: #FFFFFF; font-size: 32px; font-weight: 700;">Welcome to Rossi Tracker!</h1>
                    </td>
                  </tr>
                  
                  <tr>
                    <td style="padding: 40px;">
                      <h2 style="margin: 0 0 20px; color: #0A0A0A; font-size: 24px;">
                        Hi ${firstName}!
                      </h2>
                      
                      <p style="margin: 0 0 20px; color: #666666; font-size: 16px; line-height: 1.6;">
                        Thanks for joining Rossi Tracker! Please verify your email address to get started.
                      </p>
                      
                      <div style="background-color: #F7F7F7; padding: 20px; border-radius: 12px; margin: 30px 0; text-align: center;">
                        <p style="margin: 0 0 10px; color: #666666; font-size: 14px;">Your verification code:</p>
                        <p style="margin: 0; color: #0A0A0A; font-size: 32px; font-weight: 700; letter-spacing: 4px;">${code}</p>
                      </div>
                      
                      <table width="100%" cellpadding="0" cellspacing="0">
                        <tr>
                          <td align="center" style="padding: 20px 0;">
                            <a href="${verifyUrl}" style="display: inline-block; background: linear-gradient(135deg, #0066FF 0%, #7C3AED 100%); color: #FFFFFF; text-decoration: none; padding: 16px 40px; border-radius: 12px; font-weight: 600; font-size: 16px;">
                              Verify Email
                            </a>
                          </td>
                        </tr>
                      </table>
                      
                      <p style="margin: 30px 0 0; color: #999999; font-size: 14px; line-height: 1.6;">
                        This code will expire in 24 hours.
                      </p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </body>
      </html>
    `;

    const { data, error } = await resend.emails.send({
      from: process.env.FROM_EMAIL || 'noreply@rossitracker.com',
      to: email,
      subject: 'Verify your Rossi Tracker account',
      html: emailHtml,
    });

    if (error) {
      console.error('Failed to send verification email:', error);
      return { success: false, error };
    }

    return { success: true, data };

  } catch (error) {
    console.error('Error in sendVerificationEmail:', error);
    return { success: false, error: error.message };
  }
}

module.exports = {
  sendWeeklyReminders,
  sendVerificationEmail,
};
