import { NextRequest, NextResponse } from 'next/server';

// This route is called by Vercel Cron
// Schedule: 0 0,12 * * * (midnight and noon daily)

const { scrapeStravaClub } = require('@/../../scripts/scrape-strava');

export async function GET(request: NextRequest) {
  // Verify request is from Vercel Cron
  const authHeader = request.headers.get('authorization');
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    console.log('[Vercel Cron] Starting Strava scrape...');
    const result = await scrapeStravaClub();
    
    return NextResponse.json({
      success: true,
      message: 'Strava scrape completed',
      result,
    });
  } catch (error: any) {
    console.error('[Vercel Cron] Strava scrape failed:', error);
    return NextResponse.json(
      {
        success: false,
        error: error.message,
      },
      { status: 500 }
    );
  }
}
