import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { calculateWeightLoss, calculateWeightLossPercentage } from '@/lib/utils';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') || 'weight-loss';

    const startDate = new Date('2026-01-01');

    if (type === 'weight-loss') {
      return await getWeightLossLeaderboard(startDate);
    } else if (type === 'activities') {
      return await getActivityLeaderboards(startDate);
    }

    return NextResponse.json({ error: 'Invalid leaderboard type' }, { status: 400 });
  } catch (error) {
    console.error('Error fetching leaderboard:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

async function getWeightLossLeaderboard(startDate: Date) {
  const users = await prisma.user.findMany({
    where: {
      isActive: true,
      weights: {
        some: {
          date: {
            gte: startDate,
          },
        },
      },
    },
    include: {
      weights: {
        orderBy: { date: 'asc' },
        where: {
          date: {
            gte: startDate,
          },
        },
      },
    },
  });

  const leaderboard = users
    .map((user) => {
      const weights = user.weights;
      if (weights.length < 2) return null;

      const startWeight = weights[0].weight;
      const currentWeight = weights[weights.length - 1].weight;
      const weightLost = calculateWeightLoss(startWeight, currentWeight);
      const percentageLost = calculateWeightLossPercentage(startWeight, currentWeight);

      return {
        userId: user.id,
        name: `${user.firstName} ${user.lastName}`,
        profileImage: user.profileImage,
        startWeight,
        currentWeight,
        weightLost,
        percentageLost,
        entriesCount: weights.length,
        lastEntry: weights[weights.length - 1].date,
      };
    })
    .filter(Boolean)
    .sort((a, b) => (b?.weightLost || 0) - (a?.weightLost || 0));

  return NextResponse.json(leaderboard);
}

async function getActivityLeaderboards(startDate: Date) {
  const users = await prisma.user.findMany({
    where: { isActive: true },
    include: {
      stravaActivities: {
        where: {
          activityDate: {
            gte: startDate,
          },
        },
      },
    },
  });

  const leaderboards: any = {
    totalActivities: [],
    cycling: [],
    running: [],
    swimming: [],
    walking: [],
    gym: [],
    elevationFoot: [],
    elevationBike: [],
    cyclingDistance: [],
    walkingDistance: [],
  };

  users.forEach((user) => {
    const activities = user.stravaActivities;

    const cyclingActivities = activities.filter(
      (a) =>
        a.activityType.toLowerCase().includes('ride') ||
        a.activityType.toLowerCase().includes('cycling')
    );

    const runActivities = activities.filter((a) =>
      a.activityType.toLowerCase().includes('run')
    );

    const swimActivities = activities.filter((a) =>
      a.activityType.toLowerCase().includes('swim')
    );

    const walkActivities = activities.filter(
      (a) =>
        a.activityType.toLowerCase().includes('walk') ||
        a.activityType.toLowerCase().includes('hike')
    );

    const gymActivities = activities.filter(
      (a) =>
        a.activityType.toLowerCase().includes('weight') ||
        a.activityType.toLowerCase().includes('training') ||
        a.activityType.toLowerCase().includes('workout')
    );

    const userData = {
      userId: user.id,
      name: `${user.firstName} ${user.lastName}`,
      profileImage: user.profileImage,
    };

    leaderboards.totalActivities.push({
      ...userData,
      count: activities.length,
    });

    leaderboards.cycling.push({
      ...userData,
      count: cyclingActivities.length,
    });

    leaderboards.running.push({
      ...userData,
      count: runActivities.length,
    });

    leaderboards.swimming.push({
      ...userData,
      count: swimActivities.length,
    });

    leaderboards.walking.push({
      ...userData,
      count: walkActivities.length,
    });

    leaderboards.gym.push({
      ...userData,
      count: gymActivities.length,
    });

    const elevationFoot = [...runActivities, ...walkActivities].reduce(
      (sum, a) => sum + (a.elevationGain || 0),
      0
    );

    const elevationBike = cyclingActivities.reduce(
      (sum, a) => sum + (a.elevationGain || 0),
      0
    );

    const cyclingDistance = cyclingActivities.reduce(
      (sum, a) => sum + (a.distance || 0),
      0
    );

    const walkingDistance = [...runActivities, ...walkActivities].reduce(
      (sum, a) => sum + (a.distance || 0),
      0
    );

    leaderboards.elevationFoot.push({
      ...userData,
      elevation: elevationFoot,
    });

    leaderboards.elevationBike.push({
      ...userData,
      elevation: elevationBike,
    });

    leaderboards.cyclingDistance.push({
      ...userData,
      distance: cyclingDistance,
    });

    leaderboards.walkingDistance.push({
      ...userData,
      distance: walkingDistance,
    });
  });

  // Sort each leaderboard
  leaderboards.totalActivities.sort((a: any, b: any) => b.count - a.count);
  leaderboards.cycling.sort((a: any, b: any) => b.count - a.count);
  leaderboards.running.sort((a: any, b: any) => b.count - a.count);
  leaderboards.swimming.sort((a: any, b: any) => b.count - a.count);
  leaderboards.walking.sort((a: any, b: any) => b.count - a.count);
  leaderboards.gym.sort((a: any, b: any) => b.count - a.count);
  leaderboards.elevationFoot.sort((a: any, b: any) => b.elevation - a.elevation);
  leaderboards.elevationBike.sort((a: any, b: any) => b.elevation - a.elevation);
  leaderboards.cyclingDistance.sort((a: any, b: any) => b.distance - a.distance);
  leaderboards.walkingDistance.sort((a: any, b: any) => b.distance - a.distance);

  return NextResponse.json(leaderboards);
}
