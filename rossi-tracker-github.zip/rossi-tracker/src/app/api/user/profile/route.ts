import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { writeFile, mkdir } from 'fs/promises';
import path from 'path';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId') || session.user.id;

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        dateOfBirth: true,
        height: true,
        heightUnit: true,
        weightUnit: true,
        phoneNumber: true,
        gender: true,
        profileImage: true,
        stravaUsername: true,
        isActive: true,
        isAdmin: true,
        lastWeightEntry: true,
        createdAt: true,
        _count: {
          select: {
            weights: true,
            stravaActivities: true,
          },
        },
      },
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    return NextResponse.json(user);
  } catch (error) {
    console.error('Error fetching user profile:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const formData = await request.formData();
    
    const updateData: any = {};

    // Text fields
    const firstName = formData.get('firstName');
    const lastName = formData.get('lastName');
    const phoneNumber = formData.get('phoneNumber');
    const gender = formData.get('gender');
    const stravaUsername = formData.get('stravaUsername');
    const height = formData.get('height');
    const heightUnit = formData.get('heightUnit');
    const weightUnit = formData.get('weightUnit');

    if (firstName) updateData.firstName = firstName.toString();
    if (lastName) updateData.lastName = lastName.toString();
    if (phoneNumber) updateData.phoneNumber = phoneNumber.toString();
    if (gender) updateData.gender = gender.toString();
    if (stravaUsername) updateData.stravaUsername = stravaUsername.toString();
    if (height) updateData.height = parseFloat(height.toString());
    if (heightUnit) updateData.heightUnit = heightUnit.toString();
    if (weightUnit) updateData.weightUnit = weightUnit.toString();

    // Profile image upload
    const profileImage = formData.get('profileImage') as File;
    if (profileImage && profileImage.size > 0) {
      const bytes = await profileImage.arrayBuffer();
      const buffer = Buffer.from(bytes);

      // Create uploads directory if it doesn't exist
      const uploadsDir = path.join(process.cwd(), 'public', 'uploads', 'profiles');
      await mkdir(uploadsDir, { recursive: true });

      // Generate unique filename
      const filename = `${session.user.id}-${Date.now()}${path.extname(profileImage.name)}`;
      const filepath = path.join(uploadsDir, filename);

      await writeFile(filepath, buffer);
      updateData.profileImage = `/uploads/profiles/${filename}`;
    }

    const updatedUser = await prisma.user.update({
      where: { id: session.user.id },
      data: updateData,
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        profileImage: true,
        stravaUsername: true,
        heightUnit: true,
        weightUnit: true,
      },
    });

    return NextResponse.json(updatedUser);
  } catch (error) {
    console.error('Error updating user profile:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
