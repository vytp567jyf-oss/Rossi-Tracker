'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { Calendar, TrendingDown, Activity, Award, Plus, User, LogOut } from 'lucide-react';
import { format, subDays, subMonths, startOfYear } from 'date-fns';

const CHART_COLORS = [
  '#0066FF', '#7C3AED', '#EC4899', '#10B981', '#F59E0B',
  '#EF4444', '#06B6D4', '#F97316', '#8B5CF6', '#14B8A6'
];

export default function DashboardPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [showAddWeight, setShowAddWeight] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [dateRange, setDateRange] = useState('all');
  const [weightData, setWeightData] = useState<any[]>([]);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [activityLeaderboards, setActivityLeaderboards] = useState<any>({});

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    } else if (status === 'authenticated') {
      fetchDashboardData();
    }
  }, [status, dateRange]);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      
      // Fetch weight data for all users
      const weightRes = await fetch(`/api/weights?${getDateRangeParams()}`);
      const weights = await weightRes.json();
      
      // Fetch leaderboard
      const leaderboardRes = await fetch('/api/leaderboard?type=weight-loss');
      const leaderboardData = await leaderboardRes.json();
      
      // Fetch activity leaderboards
      const activitiesRes = await fetch('/api/leaderboard?type=activities');
      const activitiesData = await activitiesRes.json();

      setWeightData(processWeightData(weights));
      setLeaderboard(leaderboardData);
      setActivityLeaderboards(activitiesData);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getDateRangeParams = () => {
    const now = new Date();
    let startDate;

    switch (dateRange) {
      case 'week':
        startDate = subDays(now, 7);
        break;
      case 'month':
        startDate = subMonths(now, 1);
        break;
      case 'quarter':
        startDate = subMonths(now, 3);
        break;
      case 'year':
        startDate = startOfYear(now);
        break;
      default:
        return '';
    }

    return `startDate=${startDate.toISOString()}`;
  };

  const processWeightData = (weights: any[]) => {
    // Group weights by date and user
    const dataByDate: { [date: string]: any } = {};

    weights.forEach((weight) => {
      const dateKey = format(new Date(weight.date), 'MMM dd');
      
      if (!dataByDate[dateKey]) {
        dataByDate[dateKey] = { date: dateKey };
      }

      const userName = `${weight.user.firstName} ${weight.user.lastName}`;
      dataByDate[dateKey][userName] = weight.weight;
    });

    return Object.values(dataByDate);
  };

  const handleLogout = async () => {
    await fetch('/api/auth/signout', { method: 'POST' });
    router.push('/login');
  };

  if (loading || status === 'loading') {
    return (
      <div className="min-h-screen bg-rossi-white flex items-center justify-center">
        <div className="text-center">
          <div className="loading-shimmer w-16 h-16 rounded-full mx-auto mb-4" />
          <p className="text-rossi-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-rossi-white">
      {/* Header */}
      <header className="bg-white border-b border-rossi-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold gradient-text">Rossi Tracker</h1>
            </div>

            <div className="flex items-center gap-4">
              <button
                onClick={() => setShowAddWeight(true)}
                className="btn-primary flex items-center gap-2"
              >
                <Plus className="w-5 h-5" />
                <span className="hidden sm:inline">Add Weight</span>
              </button>

              <button
                onClick={() => setShowProfile(!showProfile)}
                className="w-10 h-10 rounded-full bg-gradient-to-br from-rossi-vibrant-blue to-rossi-vibrant-purple flex items-center justify-center text-white font-semibold"
              >
                {session?.user?.name?.[0] || 'U'}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Profile Menu */}
      {showProfile && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed top-16 right-4 bg-white rounded-xl shadow-lg border border-rossi-gray-200 p-4 w-64 z-50"
        >
          <div className="mb-4">
            <p className="font-semibold text-rossi-black">{session?.user?.name}</p>
            <p className="text-sm text-rossi-gray-600">{session?.user?.email}</p>
          </div>
          <div className="space-y-2">
            <button
              onClick={() => router.push('/profile')}
              className="w-full flex items-center gap-3 px-4 py-2 rounded-lg hover:bg-rossi-gray-50 transition-colors text-left"
            >
              <User className="w-5 h-5 text-rossi-gray-600" />
              <span className="text-rossi-black">My Profile</span>
            </button>
            <button
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-4 py-2 rounded-lg hover:bg-red-50 transition-colors text-left text-red-600"
            >
              <LogOut className="w-5 h-5" />
              <span>Sign Out</span>
            </button>
          </div>
        </motion.div>
      )}

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="stat-card"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center">
                <TrendingDown className="w-6 h-6 text-rossi-vibrant-blue" />
              </div>
            </div>
            <h3 className="text-sm font-medium text-rossi-gray-600 mb-1">Current Leader</h3>
            <p className="text-2xl font-bold text-rossi-black mb-1">
              {leaderboard[0]?.name || 'No data yet'}
            </p>
            <p className="text-sm text-rossi-gray-500">
              {leaderboard[0]?.weightLost ? `${leaderboard[0].weightLost} kg lost` : 'Start tracking!'}
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="stat-card"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center">
                <Activity className="w-6 h-6 text-rossi-vibrant-purple" />
              </div>
            </div>
            <h3 className="text-sm font-medium text-rossi-gray-600 mb-1">Most Active</h3>
            <p className="text-2xl font-bold text-rossi-black mb-1">
              {activityLeaderboards.totalActivities?.[0]?.name || 'No activities'}
            </p>
            <p className="text-sm text-rossi-gray-500">
              {activityLeaderboards.totalActivities?.[0]?.count || 0} activities
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="stat-card"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center">
                <Award className="w-6 h-6 text-rossi-vibrant-green" />
              </div>
            </div>
            <h3 className="text-sm font-medium text-rossi-gray-600 mb-1">Club Members</h3>
            <p className="text-2xl font-bold text-rossi-black mb-1">
              {leaderboard.length}
            </p>
            <p className="text-sm text-rossi-gray-500">Active participants</p>
          </motion.div>
        </div>

        {/* Weight Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white rounded-2xl p-6 mb-8 shadow-sm border border-rossi-gray-100"
        >
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
            <div>
              <h2 className="text-xl font-bold text-rossi-black mb-1">Weight Progress</h2>
              <p className="text-sm text-rossi-gray-600">Track everyone's journey</p>
            </div>

            <div className="flex gap-2 flex-wrap">
              {['week', 'month', 'quarter', 'year', 'all'].map((range) => (
                <button
                  key={range}
                  onClick={() => setDateRange(range)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    dateRange === range
                      ? 'bg-gradient-to-r from-rossi-vibrant-blue to-rossi-vibrant-purple text-white'
                      : 'bg-rossi-gray-100 text-rossi-gray-700 hover:bg-rossi-gray-200'
                  }`}
                >
                  {range.charAt(0).toUpperCase() + range.slice(1)}
                </button>
              ))}
            </div>
          </div>

          <div className="h-96">
            {weightData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={weightData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E3E3E3" />
                  <XAxis dataKey="date" stroke="#666666" />
                  <YAxis stroke="#666666" label={{ value: 'Weight (kg)', angle: -90, position: 'insideLeft' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#FFFFFF',
                      border: '1px solid #E3E3E3',
                      borderRadius: '12px',
                      padding: '12px',
                    }}
                  />
                  <Legend />
                  {leaderboard.slice(0, 10).map((user, index) => (
                    <Line
                      key={user.userId}
                      type="monotone"
                      dataKey={user.name}
                      stroke={CHART_COLORS[index % CHART_COLORS.length]}
                      strokeWidth={2}
                      dot={{ r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                  ))}
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center">
                <p className="text-rossi-gray-500">No weight data available yet</p>
              </div>
            )}
          </div>
        </motion.div>

        {/* Leaderboards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Weight Loss Leaderboard */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-white rounded-2xl p-6 shadow-sm border border-rossi-gray-100"
          >
            <h3 className="text-lg font-bold text-rossi-black mb-4 flex items-center gap-2">
              <Trophy className="w-5 h-5 text-yellow-500" />
              Biggest Losers (Since Jan 1st)
            </h3>
            <div className="space-y-3">
              {leaderboard.slice(0, 5).map((user, index) => (
                <div
                  key={user.userId}
                  className="flex items-center justify-between p-3 rounded-xl hover:bg-rossi-gray-50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                        index === 0
                          ? 'bg-yellow-100 text-yellow-700'
                          : index === 1
                          ? 'bg-gray-100 text-gray-700'
                          : index === 2
                          ? 'bg-orange-100 text-orange-700'
                          : 'bg-rossi-gray-100 text-rossi-gray-700'
                      }`}
                    >
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-semibold text-rossi-black">{user.name}</p>
                      <p className="text-xs text-rossi-gray-500">
                        {user.percentageLost}% lost
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-rossi-vibrant-blue">
                      {user.weightLost} kg
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Activity Leaderboard */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="bg-white rounded-2xl p-6 shadow-sm border border-rossi-gray-100"
          >
            <h3 className="text-lg font-bold text-rossi-black mb-4 flex items-center gap-2">
              <Activity className="w-5 h-5 text-rossi-vibrant-purple" />
              Most Active
            </h3>
            <div className="space-y-3">
              {activityLeaderboards.totalActivities?.slice(0, 5).map((user: any, index: number) => (
                <div
                  key={user.userId}
                  className="flex items-center justify-between p-3 rounded-xl hover:bg-rossi-gray-50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center font-bold text-sm text-purple-700">
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-semibold text-rossi-black">{user.name}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-rossi-vibrant-purple">
                      {user.count} activities
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </main>
    </div>
  );
}

function Trophy({ className }: { className?: string }) {
  return (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
    </svg>
  );
}
