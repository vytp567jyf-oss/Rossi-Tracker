import 'next-auth';

declare module 'next-auth' {
  interface Session {
    user: {
      id: string;
      email: string;
      name: string;
      image?: string | null;
      isAdmin?: boolean;
    };
  }

  interface User {
    id: string;
    email: string;
    name: string;
    image?: string | null;
    isAdmin?: boolean;
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    id: string;
    isAdmin?: boolean;
  }
}

export interface WeightEntry {
  id: string;
  userId: string;
  weight: number;
  date: Date;
  bmi: number | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface UserProfile {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  dateOfBirth: Date;
  height: number;
  heightUnit: 'metric' | 'imperial';
  weightUnit: 'metric' | 'imperial';
  phoneNumber: string | null;
  gender: string | null;
  profileImage: string | null;
  stravaUsername: string | null;
  isActive: boolean;
  isAdmin: boolean;
  lastWeightEntry: Date | null;
  createdAt: Date;
}

export interface StravaActivity {
  id: string;
  userId: string;
  stravaUsername: string;
  activityType: string;
  distance: number | null;
  elevationGain: number | null;
  activityDate: Date;
  activityName: string | null;
  movingTime: number | null;
}

export interface LeaderboardEntry {
  userId: string;
  name: string;
  profileImage: string | null;
  startWeight: number;
  currentWeight: number;
  weightLost: number;
  percentageLost: number;
  entriesCount: number;
  lastEntry: Date;
}

export interface ActivityStats {
  userId: string;
  name: string;
  profileImage: string | null;
  count?: number;
  distance?: number;
  elevation?: number;
}
